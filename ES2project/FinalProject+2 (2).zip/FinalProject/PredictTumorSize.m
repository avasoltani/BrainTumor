function [percentChange, predictedTumorArea] = PredictTumorSize(yFit, coeff, weekToPredict, yValues)
%function [percentChange, predictedTumorArea] = PredictTumorSize(yFit, coeff, weekToPredict, yValues)
%Ava Sotani
%This function predicts the change of growth of the tumor using the line
%fit of the areas versus time

predictedTumorArea = coeff(1) * weekToPredict + coeff(2);

percentChange = abs(((predictedTumorArea - yValues(end)) / yValues(end)) * 100);

end









