function [yFit,coeff,rSq]=MyLinefit(x,y,isPlotted)
%function [yFit,coeff,rSq]=MyLinefit(x,y,isPlotted)
%Ava Soltani 3/4/18
%This function takes in x value and y value vecotrs and outputs a line of
%best fit, the slope and y int of that line, and the rSq value

    if length(x) ~= length(y) || length(x) < 2 || length(y) < 2 %The vectors must
        %be the same length and 2 or more indexes long
        yFit = NaN;
        coeff = NaN;
        rSq = NaN;
        return %leave function if it doesnt meet requirments
    end

x = x(:);
y = y(:); %ensure both vectors go the same way by making them columns

x1 = ones(length(x),1); %Create a column vector with only ones the length of x

xValueMatrix(:,1) = x;
xValueMatrix(:,2) = x1; 
%Create a matrix for the values of x in one column and ones in the next 

coeff = xValueMatrix\y; %use backslash opporator to determine y values

yFit = coeff(1,1) * x + coeff(2,1); %plug the top value in for slope and the
%bottom in for y intercept into yFit = mx+b

rSq = CalcRsquared(y, yFit); %call CalcRsquared function to determine best fit 
%of line just created

    if nargin == 3 %if there are three inputs (is plotted is inputed) plot line
        plot(x, yFit,'b--')
        hold on
        plot(x,y,'ro')
        title(sprintf('R^2 = %0.4f',rSq))
        xlabel('Time (weeks)')
        ylabel('Tumor Area (pixels)')
    
    else 
        isPlotted = 0; %if there are only two inputs, the function does not plot 
        %anything
    end
end

    
    




    