function rSquared = CalcRsquared(y,yfit)
%function rSquared = CalcRsquared(y,yfit)
%Ava Soltani 3/4/18
%This function is a helper function to measure goodness of fit of a line
%given y values and fitted curve
%!!!This function is not used in my code but i left it in to not cause bugs
%when calling myLinefit!!!
    if length(y) ~= length(yfit) || isempty(y) == 1 %if the lengths arnt the 
        %same or the vec is empty the function doesnt work
        rSquared = NaN;
        return 
    end

 totSumOfSquare = sum((y - mean(y)).^2); %calulate total sum and residual sum
 resSumOfSquare = sum((y - yfit).^2);
 rSquared = 1 - (resSumOfSquare / totSumOfSquare); %plug into rsquared equation
 
end

 
 