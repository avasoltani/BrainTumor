function tumorArea = AreaTumor(tumorDimensions)
%function tumorArea = AreaTumor(tumorDimensions)
%Ava Soltani
%Calculates the area of the tumor using the area of an ellipse. 

tumorWidth = tumorDimensions(1);
tumorHeight = tumorDimensions(2);

tumorArea = tumorWidth/2 * tumorHeight/2 * pi;

end


