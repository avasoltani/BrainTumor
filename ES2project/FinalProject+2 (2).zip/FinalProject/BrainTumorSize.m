function [tumorDimensions] = BrainTumorSize(tumorImage)
%function [tumorDimensions] = BrainTumorSize(tumorImage)
%Ava Soltani
%images must be THE SAME SIZE

%Load in images (provided)
figure
tumorImage = imcrop(tumorImage);
tumorImage = rgb2gray(tumorImage);
tumorImage = imadjust(tumorImage);

imshow(tumorImage);

%CALCULATES WIDTH
longestLength = 0;
tumorWidth = 0;

    for h = 1:size(tumorImage,1) %Create loop to loop threw every row and find 
        %the greatest width of the tumor
    
        brightPointsIndexW = find(tumorImage(h,:) >= 150); %the edges of the
       %tumor are when the pixles are brightest. Becasue i greyscaled,
       %brightness goes to 255 so i chose all indexes of values greater
       %than 150 as the edges. 
    
           for n = 2:length(brightPointsIndexW) %loop through all bright points and 
               %find the two that will calculate the width of the tumor
                if brightPointsIndexW(n) - brightPointsIndexW(n-1) > tumorWidth
                tumorWidth = brightPointsIndexW(n) - brightPointsIndexW(n-1);
                elseif brightPointsIndexW == 0
                tumorWidth = 0;
               end  
           if tumorWidth > longestLength
           longestLength = tumorWidth;
           end
           end
    end

%CALCULATES HEIGHT
longestHeight = 0;
tumorHeight = 0;

%repeat for height
    for m = 1:size(tumorImage,2)
    
        brightPointsIndexH = find(tumorImage(:,m) >= 150);
    
           for p = 2:length(brightPointsIndexH)
                if brightPointsIndexH(p) - brightPointsIndexH(p-1) > tumorHeight
                tumorHeight = brightPointsIndexH(p) - brightPointsIndexH(p-1);
                elseif brightPointsIndexH == 0
                tumorWidth = 0;
                end  
            if tumorHeight > longestHeight
            longestHeight = tumorHeight;
            end
            end
     end

tumorDimensions = [tumorWidth tumorHeight];








