
Topic: Example ES-2 'readme' file
Author: B. Tracey
Date: 4/29/2015

OVERVIEW

The files in this directory explore the use of a 2-D random walk for some basic simulations of diffusion.
One of the scripts examines the effect of "container size" on the number of collisions w/ container
walls, which is a surrogate for pressure.

WHERE TO START

A good starting point is example2dwalk.m, which calls the main calculation function 
(randomWalk2d_box.m) and plots the output.


RUN SCRIPTS

1) example2dWalk.m - script that calculates the 2-d walk for one box size 

2) runBoxSizeEffect.m - script that examines how the number of collisions with the wall 
(a surrogate for pressure of a gas) depends on the size of the enclosing box


CALCULATION FUNCTIONS

1) randomWalk2d_box.m - this file implements a 2d random walk for particles in a box, 
 	counting # collisions with wall


GRAPHING / SUPPORT FUNCTIONS

1) boldify.m - increases line widths and sets text font to bold
