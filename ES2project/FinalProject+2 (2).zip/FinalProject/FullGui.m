function varargout = FullGui(varargin)
% FULLGUI MATLAB code for FullGui.fig
%      FULLGUI, by itself, creates a new FULLGUI or raises the existing
%      singleton*.
%
%      H = FULLGUI returns the handle to a new FULLGUI or the handle to
%      the existing singleton*.
%
%      FULLGUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in FULLGUI.M with the given input arguments.
%
%      FULLGUI('Property','Value',...) creates a new FULLGUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before FullGui_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to FullGui_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help FullGui

% Last Modified by GUIDE v2.5 10-May-2018 13:03:45

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @FullGui_OpeningFcn, ...
                   'gui_OutputFcn',  @FullGui_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before FullGui is made visible.
function FullGui_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to FullGui (see VARARGIN)

% Choose default command line output for FullGui
handles.output = hObject;
%numWeeksApart = str2double(get(handles.output,'string'));
% Update handles structure
guidata(hObject, handles);

% UIWAIT makes FullGui wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = FullGui_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



function edit2_Callback(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit2 as text
%        str2double(get(hObject,'String')) returns contents of edit2 as a double
nWeeks = str2num(get(hObject,'String'))
handles.edit2.UserData = nWeeks;

%keyboard

% --- Executes during object creation, after setting all properties.
function edit2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit3_Callback(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit3 as text
%        str2double(get(hObject,'String')) returns contents of edit3 as a double

weeksPredict = str2num(get(hObject,'String'))
handles.edit3.UserData = weeksPredict;

% --- Executes during object creation, after setting all properties.
function edit3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%save gui variables
nWeeks = handles.edit2.UserData;
weeksPredict = handles.edit3.UserData;

%load example images
tumorImage1 = imread('tumor2.jpg');
tumorImage2 = imread('tumor3.jpg');
tumorImage3 = imread('tumor4.jpg');
tumorImage4 = imread('tumor5.jpg');

%Images if you want to see growth
%[tumorArea1] = AreaTumor(BrainTumorSize(tumorImage1));
%[tumorArea2] = AreaTumor(BrainTumorSize(tumorImage2));
%[tumorArea3] = AreaTumor(BrainTumorSize(tumorImage3));
%[tumorArea4] = AreaTumor(BrainTumorSize(tumorImage4));

[tumorArea1] = AreaTumor(BrainTumorSize(tumorImage4));
[tumorArea2] = AreaTumor(BrainTumorSize(tumorImage3));
[tumorArea3] = AreaTumor(BrainTumorSize(tumorImage2));
[tumorArea4] = AreaTumor(BrainTumorSize(tumorImage1));

yValues = [tumorArea1 tumorArea2 tumorArea3 tumorArea4];
xValues = (1:nWeeks:nWeeks*length(yValues));

[yFit,coeff,rSq]=MyLinefit(xValues,yValues,3);
%plug in week values and tumor areas into MyLineFit

weekToPredict = nWeeks * length(yValues) + weeksPredict;
%find the number of weeks from begining that prediction is wanted

[percentGrowth, predictedTumorArea] = PredictTumorSize(yFit, coeff, weekToPredict, yValues);

%OUTPUT DATA    
    if predictedTumorArea > yValues(end)
       growOrShrink = 'grow';
    elseif predictedTumorArea < yValues(end)
        growOrShrink = 'shrink';
    end
    
    if predictedTumorArea <=0
       x = sprintf('Congrats! In %0.1f weeks, you will be cancer free\n', weeksPredict);
       msgbox(x);
    elseif predictedTumorArea ~= yValues(end)
       x = sprintf('In %0.1f weeks, your tumor will %s by %0.1f percent\n', weeksPredict, growOrShrink, percentGrowth);
       msgbox(x);
    elseif predictedTumorArea ~= yValues(end)
       x = printf('In %0.1f weeks, your tumor will remain the same size\n', weeksPredict);
       msgbox(x);
    end
    
%Save text file
fid = fopen('sizePrediction.txt','wt');
fprintf(fid,'%s',x);




        
